<?php

define('HOST','162.214.92.178');
define('USER','prodapro');
define('SENHA','Pr0d@5Iq');
define('BD','prodapro_down');

/*
define('HOST','localhost');
define('USER','root');
define('SENHA','');
define('BD','prodapro_down');
*/

?>