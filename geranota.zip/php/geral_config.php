<?php
$empresa="B V COMERCIO DE PRODUTOS ALIMENTICIOS LTDA";
$somtribcusto="S";
$atualizaprecocusto="S";

?>