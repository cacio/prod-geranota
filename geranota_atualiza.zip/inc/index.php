<?php

header("location: ../php/login.php");

?>
 